package ATM_machine;

import java.util.Scanner;

class ATM{
    float Balance;
    int PIN=9821;
    public void CheckPin(){
        System.out.println("Welcome To ATM \n");
        System.out.print("Enter your PIN :");
        Scanner sc=new Scanner(System.in);
        int Entered_Pin=sc.nextInt();
        if(Entered_Pin==PIN){
            menu();
        }
        else{
            System.out.println("PIN is Wrong ");
            System.out.println("Enter your Valid Pin :\n");
        }
       // menu();
    }

    public void menu(){
        System.out.println("Enter your choice ");
        System.out.println("1. check your A/C Balance ");
        System.out.println("2. withdrawal money ");
        System.out.println("3. Deposit money");
        System.out.println("4. EXIT ");

        Scanner sc=new Scanner (System.in);
        int opt=sc.nextInt();

        if(opt==1){
            checkBalance();

        }
        else if (opt==2){
            WithdrawalMoney();
        }
        else if(opt==3){
            DepositMoney();
        }
        else if (opt==4) {
            return;
        }
        else{
            System.out.println("Enter your valid choice ");
        }
    }
    public void checkBalance(){
        System.out.print(" Total Balance: "+Balance+"\n");
        System.out.println("..................................");
        menu();
    }
    public void WithdrawalMoney(){
        System.out.print("Enter  Withdrawal Amount :");
        Scanner sc =new Scanner(System.in);
        float amount=sc.nextFloat();
        if(amount>Balance){
            System.out.println("Insufficient Balance \n");

        }
        else{
            Balance =Balance -amount;
            System.out.println("Money Withdrawal successfully ");
            System.out.println("..............Thank You ...............\n");

        }
        menu();

    }
    public void DepositMoney(){
        System.out.print("Enter the Deposit Amount :");
        Scanner sc=new Scanner(System.in);
        float amount =sc.nextFloat();
        Balance =Balance+amount;
        System.out.println("Money Deposit is Successfully ");
        System.out.println("..................Thank you................. \n");
        menu();
    }

}

public class ATM_machine {
    public static void main(String[] args) {
        ATM obj=new ATM();
        obj.CheckPin();

    }
}
